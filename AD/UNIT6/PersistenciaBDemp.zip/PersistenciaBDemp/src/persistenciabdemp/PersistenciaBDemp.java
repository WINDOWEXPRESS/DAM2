
package persistenciabdemp;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistenciaBDemp {

    
    public static void main(String[] args) {
        
        EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("PersistenciaBDempPU");
       //metodo1(emf);
       metodo2(emf);
    }
    
    public static void metodo1(EntityManagerFactory emf){
     DeptJpaController dao = new DeptJpaController(emf);
        List <Dept> lista = dao.findDeptEntities();
        for( Dept departamento : lista){
            System.out.println("nombre departamento :" +departamento.getDname());
        }
  }
    
    public static void metodo2(EntityManagerFactory emf){
        EntityManager em = emf.createEntityManager();
        Dept undept = new Dept();
        undept.setDeptno(60);
        undept.setDname("RRHH");
        undept.setLoc("Burgos");
            em.getTransaction().begin();
            em.persist(undept);
            em.getTransaction().commit();
    }
}
