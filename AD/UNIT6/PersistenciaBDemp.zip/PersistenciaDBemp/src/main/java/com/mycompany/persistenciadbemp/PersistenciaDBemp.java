/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.persistenciadbemp;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author at4dam2
 */
public class PersistenciaDBemp {

    public static void main(String[] args) {
        EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("PersistenciaDBempPU");
        DeptJpaController dao = new DeptJpaController(emf);
        List<Dept> lista = dao.findDeptEntities();
        for (Dept dept : lista) {
            System.out.println("Nombre departamento: "+dept.getDname());
        }
        
        Dept nuevoDept = new Dept();
        nuevoDept.setDeptno(60);
        nuevoDept.setDname("RRHH");
        nuevoDept.setLoc("Burgos");
        try {
            dao.create(nuevoDept);
        } catch (Exception ex) {
            Logger.getLogger(PersistenciaDBemp.class.getName()).log(Level.SEVERE, null, ex);
        }
                
    }
}
