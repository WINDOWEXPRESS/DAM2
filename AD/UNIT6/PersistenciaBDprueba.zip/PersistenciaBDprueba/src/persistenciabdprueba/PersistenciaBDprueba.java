
package persistenciabdprueba;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistenciaBDprueba {

    public static void main(String[] args) {
   
       EntityManagerFactory emf = Persistence.createEntityManagerFactory("PersistenciaBDpruebaPU");
       PersonasJpaController dao = new PersonasJpaController(emf);
       List <Personas> lista = dao.findPersonasEntities();
       for ( Personas nombres :lista){
           System.out.println("Nombres personas: "+nombres.getNombres()+" "+nombres.getEdad());
       }
       //metodo2(emf);
    }
     public static void metodo2(EntityManagerFactory emf){
        EntityManager em = emf.createEntityManager();
        Personas unpersonas = new Personas();
        unpersonas.setId(5);
        unpersonas.setNombres("nacho");
        unpersonas.setApellidos("Ramirez");
        unpersonas.setSalario(2999);
        unpersonas.setEdad(19);
            em.getTransaction().begin();
            em.persist(unpersonas);
            em.getTransaction().commit();
    }
    
}
