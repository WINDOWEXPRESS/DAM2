/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.persistenciadbemp;

/**
 *
 * @author at4dam2
 */
public class PersistenciaDBemp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
