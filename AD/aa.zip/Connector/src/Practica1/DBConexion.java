/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica1;

/**
 *
 * @author at4dam2
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConexion {

    private static Connection con = null;
    private static final String DRIVE = "com.mysql.cj.jdbc.Driver"; //el driver varia segun la DB que usemos
    private static final String URL = "jdbc:mysql://localhost:3306/ad?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String PWD = "";
    private static final String USR = "root";

    public static Connection getConnection() {
        try {
            if (con == null) {
                Class.forName(DRIVE);
                con = DriverManager.getConnection(URL, USR, PWD);
                System.out.println("Conection Succesfull");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return con;
    }
}
