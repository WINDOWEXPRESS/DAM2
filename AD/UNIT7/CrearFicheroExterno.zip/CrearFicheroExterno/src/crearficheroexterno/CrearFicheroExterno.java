
package crearficheroexterno;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.xquery.*;
import net.xqj.exist.ExistXQDataSource;



public class CrearFicheroExterno {

   
    public static void main(String[] args) throws XQException{
        String nom_archivo = "NUEVO_EMPLEO10.xml";
        File fichero = new File(nom_archivo);
        XQDataSource server = new ExistXQDataSource();
            server.setProperty("serverName","localhost");
            server.setProperty("port","8080");
        XQConnection conn = server.getConnection();
        XQPreparedExpression consulta = conn.prepareExpression (
        "let $titulo:=/EMPLEADOS/TITULO\n" +
        "return \n" +
        "<EMPLEADOS>{$titulo} {for $em in /EMPLEADOS/fila_emple[DEPT_NO=30]  return $em}\n" +
        "</EMPLEADOS>");
        XQResultSequence result = consulta.executeQuery();
        if (fichero.exists()){
            if(fichero.delete()) System.out.println("Archivo borrado. Creo de nuevo");
            else System.out.println("Error al borrar el Archivo");
        }
         try{
             BufferedWriter bw = new BufferedWriter (new FileWriter(nom_archivo));
             bw.write("<?xml version='1.0' encoding 'ISO-8859-1'?>"+"\n");
             while(result.next()){
                 String cad = result.getItemAsString(null);
                 System.out.println(" output "+cad);//visualizamos
                 bw.write(cad+"\n");
             }
             bw.close();
         }catch(IOException ioe){ioe.printStackTrace();}
         conn.close();
    }
    
}
