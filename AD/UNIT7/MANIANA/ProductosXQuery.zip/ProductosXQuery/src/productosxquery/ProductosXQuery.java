
package productosxquery;

import javax.xml.xquery.*;
import net.xqj.exist.ExistXQDataSource;

public class ProductosXQuery {

    public static void main(String[] args) throws Exception{
        
        XQDataSource server = new ExistXQDataSource();
        server.setProperty("serverName", "localhost");
        server.setProperty("port", "8080");
        server.setProperty("user","admin");
        server.setProperty("password","admin");
            XQPreparedExpression consulta;
            XQResultSequence resultado;
            
                XQConnection conn = server.getConnection();
                
                System.out.println("----consulta documentos productos.xml-------");
                consulta=conn.prepareExpression("for $de in /productos return $de");
                resultado=consulta.executeQuery();
                while (resultado.next()){
                    System.out.println("Elemento "+resultado.getItemAsString(null));
                }
                //la conexion se tiene que cerrar fuera del bucle while
                //si no se hace, te visualizara los datos pero te dara un XQException al final
            conn.close();
    }
    
}
