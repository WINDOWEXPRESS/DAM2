package Principal;

import java.util.concurrent.Semaphore;

public class Jugador extends Thread 
{
	// S1 abierto indicará que el Jugador 1 ha dejado su jugada en numeroOponente1
	private static Semaphore s1 = new Semaphore (0);
	// S2 abierto indicará que el Jugador 2 ha dejado el resultado en seguir_jugandoOp1
	private static Semaphore s2 = new Semaphore (0);
	// mutex asegura el acceso exclusivo a los recursos compartidos (static) 
	private static Semaphore mutex = new Semaphore (1);

	private static int total = 10; // Número de jugadores
	private static int nOrdenGlobal=0; // Contador de número de orden de los hilos 
	private static int numeroOponente1; // Variable que almacena el número del hilo 1
	private static boolean seguir_jugandoOp1; // Variable que almacena el resultado para hilo 1
	private static int terminan = 0; // Contador de los hilos al salir tras una jugada
	
	private int nOrden; // Número de orden del hilo actual
	private int numero; // Jugada del hilo actual
	private boolean seguir_jugando = true; // Resultado del hilo actual
	
	public Jugador(int numero)
	{
		this.numero = numero;
	}
	
	public void run()
	{
		boolean fin=false; // Para forzar la finalización de un hilo (el último).
		while (seguir_jugando==true && fin==false)
		{
			try 
			{
				mutex.acquire();
				nOrdenGlobal++; // Incrementamos el contador de hilos que entran
				//System.out.println("Entra el "+nOrdenGlobal);
				nOrden = nOrdenGlobal; // Asignamos localmente al hilo su número de orden
				if (nOrden==1)
					numeroOponente1=numero; // Si es el primero aprovechamos para guardar su jugada
			} 
			catch (InterruptedException e) {e.printStackTrace();}
			finally 
			{
				mutex.release();
			}
			
			if (nOrden==1)
			{
				primero();
				salir();
			}
			
			else
				if (nOrden==2)
				{
					segundo();
					salir();

				}
				else
					seguir_jugando=true;
			
			try 
			{
				mutex.acquire();
				if (seguir_jugando==false) // Para informar de los que van perdiendo
				{
					total--;
					System.out.println("El "+numero+" pierde. Quedan="+total );
				}
				if (total<2) // Cuando solo quede uno forzamos el final
				  fin=true;
			} 
			catch (InterruptedException e) {e.printStackTrace();}
			finally 
			{
				mutex.release();
			}
		}
		if (seguir_jugando==true) // Si terminó por ser el último  
			System.out.println("Gana el "+numero);
	}
	
	// Este método contabiliza la "salida" de los hilos tras jugar
	// para que el último (el A o el B) inicialicen el contador de nOrdenGlobal
	public void salir()
	{
		try 
		{
			mutex.acquire();
			terminan++;
			if (terminan==2) //
			{
				nOrdenGlobal=0;
				terminan=0;
			}
		} catch (InterruptedException e) {e.printStackTrace();}
		finally
		{
			mutex.release();
		}
	}
	
	public void primero()
	{
		try 
		{
			System.out.println("Jugador A: "+numero);
			s1.release(); // Aviso de que ya está mi número en su sitio
			s2.acquire(); // Espero hasta que esté listo el resultado del juego
			
			mutex.acquire();
			seguir_jugando = seguir_jugandoOp1;
		} 
		catch (InterruptedException e) {e.printStackTrace();}
		finally
		{
			mutex.release();	
		}
	}

	public void segundo()
	{
		char letra;
		try {
			s1.acquire(); // ¿Está el número del oponente en su sitio?
		} catch (InterruptedException e) {e.printStackTrace();}
		System.out.println("Jugador B: "+numero);
		
		try {
			mutex.acquire();
			jugar();
		} 
		catch (InterruptedException e) {e.printStackTrace();}
		finally 
		{
			mutex.release();
		}
		letra = (seguir_jugando==true)?'B':'A';
		System.out.println("Entre "+numeroOponente1+" y "+numero+" gana "+letra);
		s2.release(); // Aviso de que está listo el resultado
	}
	
	public void jugar()
	{
		seguir_jugando = true;
		seguir_jugandoOp1 = true;
		
		if (numero > numeroOponente1)
			seguir_jugandoOp1=false;
		else
			if (numero < numeroOponente1)
				seguir_jugando=false;
	}
}
