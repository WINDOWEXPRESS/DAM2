/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author at4dam2
 */
public class Connector {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //usar el try catch resouces para cierre automatico
            try (Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/ad?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", ""); 
                    Statement st = connect.createStatement(); 
                    ResultSet rs = st.executeQuery("select * from EMP where deptno=30")) {
                
                System.out.println("Las tablas de las Base de datos de Alumnos son:");
                while (rs.next()) {
                    //imprimir los datos obtenido
                    System.out.print("empno: " + rs.getString(1) + " ");
                    System.out.print("ename: " + rs.getString(2) + " ");
                    System.out.print("job: " + rs.getString(3) + " ");
                    System.out.println("");
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(Connector.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Connector.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
