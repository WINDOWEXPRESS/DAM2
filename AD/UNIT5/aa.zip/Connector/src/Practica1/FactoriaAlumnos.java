/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica1;

/**
 *
 * @author at4dam2
 */
public class FactoriaAlumnos {

    public static AlumnoInterface getAlumnoDao() {

        return new AlumnoBean();
    }

}
