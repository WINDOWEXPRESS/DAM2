/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica1;

import java.util.Collection;
import java.util.Date;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author at4dam2
 */
public class AlumnoBean implements AlumnoInterface {

    private String NUMEXPDTE;
    private String nombre;
    private String ciclo;
    private String dni;
    private java.util.Date fecha;
    private java.sql.Connection conexion = null;

    @Override
    public String getNUMEXPDTE() {
        return this.NUMEXPDTE;
    }

    @Override
    public String getNombre() {
        return nombre; // no es obligatorio poner this
    }

    @Override
    public String getCiclo() {
        return ciclo;
    }

    @Override
    public String getDni() {
        return dni;
    }

    @Override
    public Date getFecha() {
        return fecha;
    }

    @Override
    public void setNombre(String nombre) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;

        try {
            sentencia = conexion.createStatement();
            sentencia.execute(
                    "UPDATE ALUMNO SET NOMBRE='" + nombre
                    + "'WHERE NUMEXPDTE='" + this.NUMEXPDTE + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de nombre sobre ALUMNO");
            return;
        }
        this.nombre = nombre;
    }

    @Override
    public void setCiclo(String ciclo) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;
        try {
            sentencia = conexion.createStatement(); //se crea la sentencia

            sentencia.execute(
                    "UPDATE ALUMNO SET CICLO='" + ciclo
                    + "'WHERE NUMEXPDTE='" + this.NUMEXPDTE + "'");
            //modifico el nombre, con el nombre que nos dan de aquel cuyo expdiente coincida con el objeto actual
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de ciclo sobre ALUMNO");
            return;
        }

        this.ciclo = ciclo;
    }

    @Override
    public void setDni(String dni) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;
        try {
            sentencia = conexion.createStatement();

            sentencia.execute(
                    "UPDATE ALUMNO SET DNI='" + dni
                    + "'WHERE NUMEXPDTE='" + this.NUMEXPDTE + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de dni sobre ALUMNO");
            return;
        } catch (Exception e) {
            System.out.println(e.getClass());
            return;
        }

        this.dni = dni;
    }

    @Override
    public void setFecha(Date fecha) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;
        try {
            sentencia = conexion.createStatement();
            sentencia.execute(
                    "UPDATE ALUMNO SET FECNAC='" + fecha
                    + "'WHERE NUMEXPDTE='" + this.NUMEXPDTE + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de fecha sobre ALUMNO");
            return;
        }
        this.fecha = fecha;
    }

    @Override
    public AlumnoInterface getAlumnoPorNUMEXPDTE(String NUMEXPDTE) {

        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;
        AlumnoBean alumno = null;
        try {
            sentencia = conexion.createStatement(); //se crea la sentencia

            alumno = new AlumnoBean();
            //se le da valor ejecutandola
            java.sql.ResultSet resultado;
//executeQuery devuelve ResulSet, que es un cursor
            resultado = sentencia.executeQuery(
                    "SELECT * FROM ALUMNO"
                    + "WHERE NUMEXPDTE='" + NUMEXPDTE + "'"
            );

            while (resultado.next()) {
                alumno.NUMEXPDTE = resultado.getString("NUMEXPDTE");
//al método getString le paso el nombre de la columna y me devuelve el valor de la columna como un String 
                alumno.ciclo = resultado.getString("CICLO");
                alumno.dni = resultado.getString("DNI");
                alumno.nombre = resultado.getString("NOMBRE");
                //en java hay dos tipos de Date:
                //java.util.date
                //java.sql.date --> para compatibilizar las fechas entre bbdd
                //getDAte devuelve java.sql.date y el alumno.fecha es de tipò java.util.date 
                //y tengo que hacer una conversión
                alumno.fecha = resultado.getDate("FECHA");
            }
            resultado.close();
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en SELECT de Alumno por NUMEXPDTE sobre ALUMNO");
            return null;
        }
        return alumno;
    }

    @Override
    public Collection getAlumnoPorCiclo(String ciclo
    ) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;

        AlumnoBean alumno = null;
        java.util.Collection coleccion = null;

        try {
            sentencia = conexion.createStatement();
            coleccion = new java.util.Vector();

            //Collection no se puede instanciar, pq es un interfaz, utilizamos un Vector, un vector es un obj coleccion
            java.sql.ResultSet resultado;
            resultado = sentencia.executeQuery("SELECT * FROM ALUMNO" + "WHERE CICLO='" + ciclo + "'");

            while (resultado.next()) {
                alumno = new AlumnoBean();
                alumno.NUMEXPDTE = resultado.getString("NUMEXPDTE");
                alumno.ciclo = resultado.getString("CICLO");
                alumno.dni = resultado.getString("DNI");
                alumno.nombre = resultado.getString("NOMBRE");
                alumno.fecha = resultado.getDate("FECHA");
                coleccion.add(alumno);
            }
            resultado.close();
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en SELECT de Alumno por ciclo sobre ALUMNO");
            return null;
        }
        return coleccion; // Devuelve una colección de alumnos.
    }

    @Override
    public Collection getAlumnoPorNombre(String nombre
    ) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;
        AlumnoBean alumno = null;
        java.util.Collection coleccion = null;

        try {
            sentencia = conexion.createStatement();
            coleccion = new java.util.Vector();
            java.sql.ResultSet resultado;

            resultado = sentencia.executeQuery(
                    "SELECT * FROM ALUMNO"
                    + "WHERE NOMBRE='" + nombre + "'");

            while (resultado.next()) {
                alumno = new AlumnoBean();
                alumno.NUMEXPDTE = resultado.getString("NUMEXPDTE");
                alumno.ciclo = resultado.getString("CICLO");
                alumno.dni = resultado.getString("DNI");
                alumno.nombre = resultado.getString("NOMBRE");
                alumno.fecha = resultado.getDate("FECHA");
                coleccion.add(alumno);
            }
            resultado.close();
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en SELECT de Alumno por nombre sobre ALUMNO");
            return null;
        }
        return coleccion;
    }

    @Override
    public void delete() {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;
        try {
            sentencia = conexion.createStatement();
            sentencia.execute(
                    "DELETE FROM ALUMNO WHERE NUMEXPDTE='" + this.NUMEXPDTE + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error DELETE sobre ALUMNO");
            return;
        };

        // REInicializamos las var a su valor por defecto, ya que en java no se
        // puede destruir un objeto, por si alguien tiene una ref de este obj
        // aunque lo hayamos borrado de la base de datos , puede parecer que el obj
        //existe, para evitalo hacemos esto.
        this.ciclo = null;
        this.dni = null;
        this.NUMEXPDTE = null;
        this.fecha = null;
        this.conexion = null;
        this.nombre = null;
    }

    @Override
    public AlumnoInterface getNuevoAlumno(String NUMEXPDTE, String nombre,
            String Ciclo, String dni
    ) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;

        try {
            sentencia = conexion.createStatement();
            sentencia.execute("INSERT INTO ALUMNO(NUMEXPDTE,NOMBRE,DNI,CICLO,FECNAC VALUES('"
                    + NUMEXPDTE + "'  ,'" + nombre + "','" + dni + "','" + ciclo + "',"
                    + new java.sql.Date(fecha.getTime()) + ")' ");
        } catch (SQLException e) {
            System.out.println("Error SQL al insertar Alumno" + e.getMessage());
            return null;
        }
        //Instanciamos alumno nuevo y le damos los valores a sus atributos
        AlumnoBean alumno = new AlumnoBean();

        alumno.NUMEXPDTE = NUMEXPDTE;
        alumno.dni = dni;
        alumno.fecha = fecha;
        alumno.nombre = nombre;
        alumno.ciclo = Ciclo;
//devuelvo el objeto alumno
        return alumno;

    }
    //METODO PARA ESTABLECER LA CONEXIÓN

    private java.sql.Connection getConexion() {
        //Cargar el driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //Obtener el driver
        } catch (ClassNotFoundException e) {
            System.out.println("No se encuentra la clase del Driver");
            return null; //devuelve null si va mal
        }
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/ad?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "");
        } catch (SQLException e) {
            System.out.println("No se puede obtener la conexión");
            return null;
        }
        return conexion;
    }

}
