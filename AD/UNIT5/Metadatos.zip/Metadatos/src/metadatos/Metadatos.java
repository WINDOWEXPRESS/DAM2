
package metadatos;

import java.sql.*;
public class Metadatos {


    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        
        System.out.println("Getting connection");
        Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_alumnos","root","");
        Statement ps=c.createStatement();
        DatabaseMetaData md=c.getMetaData();
        ResultSet rs=md.getTables(null,null,null,null);
        
        System.out.println("Las tablas son: ");
        while(rs.next()){
            String nTabla=rs.getString(3);
            System.out.println(nTabla);
        }
        rs.close();
        ps.close();
        c.close();
     
    
}
}