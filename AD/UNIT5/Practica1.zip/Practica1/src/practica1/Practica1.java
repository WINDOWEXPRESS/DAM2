
package practica1;
import java.sql.*;

public class Practica1 {
    public static void main(String[] args)throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        
        System.out.println("Getting connection");
        Connection c = DriverManager.getConnection("jdbc:mysql://localhost/bd_alumnos","root","");
            Statement ps = c.createStatement();
            ResultSet rs = ps.executeQuery("Select * from alumnos");
        while(rs.next()){
                String ap = rs.getString("apellidos");
                String n = rs.getString("nombre");
                String ti = rs.getString("titulacion");
               System.out.println("Nombre "+n+" apellido "+ap+" titulacion"+ti);
            
        }
        rs.close();
        ps.close();
        c.close();
    }
    
}
