/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import com.mysql.cj.jdbc.DatabaseMetaData;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author at4dam2
 */
public class Bd_alumnos_menu {

    private static Connection con = null;
    //private static final String DRIVE = "com.mysql.cj.jdbc.Driver"; //el driver varia segun la DB que usemos
    private static final String URL = "jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String PWD = "";
    private static final String USR = "root";
    private ResultSet rs;

    public static Connection getConnection() {
        try {
            System.out.println("Getting connection");
            if (con == null) {
                //Class.forName(DRIVE);
                con = DriverManager.getConnection(URL, USR, PWD);
                System.out.println("Conection Succesfull");
            }
        } catch (SQLException ex) {
            System.out.println("Error Conection");
        }
        return con;
    }

    public void listarTablas() {
        try {
            System.out.println("Las tablas de la base de datos: ");
            DatabaseMetaData md = (DatabaseMetaData) con.getMetaData();
            rs = md.getTables("bd_alumnos", null, null, null);
            while (rs.next()) {
                System.out.println(rs.getString(3));
            }
        } catch (SQLException ex) {
            System.out.println("Listar tablas fallido.");
        }
    }

    public void obtenerTabla(String Tabla) {

    }

    public void mostrarTabla(String Tabla) {

    }

}
