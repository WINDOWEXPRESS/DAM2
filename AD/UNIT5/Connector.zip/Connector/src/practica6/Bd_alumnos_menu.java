/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import com.mysql.cj.jdbc.DatabaseMetaData;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;

/**
 *
 * @author at4dam2
 */
public class Bd_alumnos_menu {

    private static Connection con = null;
    //private static final String DRIVE = "com.mysql.cj.jdbc.Driver"; //el driver varia segun la DB que usemos
    private static final String URL = "jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String PWD = "";
    private static final String USR = "root";
    private ResultSet rs;
    private Statement sentencia;
    private List<String> listaTabla;

    public static Connection getConnection() {
        try {
            System.out.println("Getting connection");
            if (con == null) {
                //Class.forName(DRIVE);
                con = DriverManager.getConnection(URL, USR, PWD);
                System.out.println("Conection Succesfull");
            }
        } catch (SQLException ex) {
            System.out.println("Error Conection");
        }
        return con;
    }

    public void listarTablas() {
        try {
            listaTabla = new ArrayList<String>();
            System.out.println("Las tablas de la base de datos: ");
            DatabaseMetaData md = (DatabaseMetaData) con.getMetaData();
            rs = md.getTables("bd_alumnos", null, null, null);
            if (!rs.next()) {
                System.out.println("No hay datos.");
            } else {
                do {
                    System.out.println(rs.getString(3));
                    listaTabla.add(rs.getString(3));
                } while (rs.next());
            }

        } catch (SQLException ex) {
            System.out.println("Listar tablas fallido.");
        }
    }

    public ResultSet obtenerTabla(String tabla) {
        try {
            sentencia = con.createStatement();
            rs = sentencia.executeQuery(
                    "SELECT * FROM bd_alumnos." + tabla);

        } catch (SQLException ex) {
            Logger.getLogger(Bd_alumnos_menu.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }

    public void mostrarTabla(int opcionTabla) {
        try {
            obtenerTabla(listaTabla.get(opcionTabla));
            ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next()) {

                for (int i = 1; i <= columnCount; i++) {
                    System.out.print(rs.getString(i) + " ");
                }
                //salto de linea
                System.out.println("");
            }

        } catch (SQLException ex) {
            Logger.getLogger(Bd_alumnos_menu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public List<String> getListaTabla() {
        return listaTabla;
    }
}
