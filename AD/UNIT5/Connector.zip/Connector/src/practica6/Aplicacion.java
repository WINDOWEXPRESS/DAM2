/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

/**
 *
 * @author at4dam2
 */
public class Aplicacion {
    public static void main(String[] args) {
        
    }
    public static void menu(){

}
}

