/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author at4dam2
 */
public class Aplicacion {
    private static int opc;
    public static void main(String[] args) {
        Connection conexion = Bd_alumnos_menu.getConnection();
        Bd_alumnos_menu bd_alumnos_menu = new Bd_alumnos_menu();

        bd_alumnos_menu.listarTablas();
        menu(bd_alumnos_menu.getListaTabla());
        bd_alumnos_menu.mostrarTabla(opcion()-1);
    }

    public static void menu(List<String> lista) {
        System.out.println("===========================================");
        for (int i = 0; i < lista.size(); i++) {
            String s = lista.get(i);
            System.out.println((i + 1) + ". " + s);
        }
        System.out.println("===========================================");
        if(!lista.isEmpty()){
            //Leer opcion de usuario
            System.out.print("Opcion (" + (lista.isEmpty() ? 0 : 1) + " - " + lista.size() + "):");
        }

    }

    public static int opcion() {
        //BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        Scanner entrada = new Scanner(System.in);
        opc = entrada.nextInt();
        return opc;
    }

}
