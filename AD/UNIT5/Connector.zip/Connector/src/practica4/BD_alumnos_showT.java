/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;
import Practica1.DBConexion;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author Usuario
 */
public class BD_alumnos_showT {
    
    public static void ListarTablas() throws SQLException{
        System.out.println("Getting connection");
        try (Connection c = DBConexion.getConnection(); Statement ps = c.createStatement(); ResultSet rs = ps.executeQuery("Show tables FROM bd_alumnos")) {
            System.out.println("Las tablas son: ");
            while(rs.next()){
                String nTabla=rs.getString(1);
                System.out.println(nTabla);
            }
        }
    } 
}
