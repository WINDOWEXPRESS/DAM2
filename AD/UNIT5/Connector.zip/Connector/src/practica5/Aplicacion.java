/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica5;

import Practica1.DBConexion;
import com.mysql.cj.jdbc.DatabaseMetaData;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author at4dam2
 */
public class Aplicacion {
    public static void main(String[] args) {
        try {
            System.out.println("Getting connection");
            
            Connection c = DBConexion.getConnection();

            System.out.println("Las tablas son: ");
            DatabaseMetaData md = (DatabaseMetaData) c.getMetaData();
            ResultSet rs=md.getTables("bd_alumnos", null, null, null);
            while(rs.next()){
             System.out.println(rs.getString(3));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Aplicacion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
