/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica1;

/**
 *
 * @author at4dam2
 */
public class Aplicacion {

    public static void main(String[] args) {
        /*
        //Ejecucion 1
        //Dar de alta un nuevo alumno ("105","ENRIQUETA ","ASIR","3434343", null)
        FactoriaAlumnos.getAlumnoDao().getNuevoAlumno("105", "ENRIQUETA", "ASI", "3434343",null);
       
        //Modificar los datos del alumno ENRIQUETA POR Nombre BLANCA, dni 55555555, ciclo DAM
        FactoriaAlumnos.getAlumnoDao().setNombre("BLANCA", "105");
        FactoriaAlumnos.getAlumnoDao().setDni("555555555", "105");
        FactoriaAlumnos.getAlumnoDao().setCiclo("DAM", "105");
        
        //comprueba la modificacion
        System.out.println(FactoriaAlumnos.getAlumnoDao().getAlumnoPorNombre("BLANCA"));
         */
        /*
        //Ejecucion 2
        System.out.println("Lista alumnos del DAM:");
        System.out.println("-----------------------------------");
        Collection<AlumnoBean> listaAlumnoDam = FactoriaAlumnos.getAlumnoDao().getAlumnoPorCiclo("DAM");
        for (AlumnoBean next : listaAlumnoDam) {
            System.out.println(next.getNombre());
        } 
         *//*
        //Ejecucion 3
        Collection<AlumnoBean> listaAlumnoJuan = FactoriaAlumnos.getAlumnoDao().getAlumnoPorNombre("Juan");
        for (AlumnoBean next : listaAlumnoJuan) {
            System.out.println("DAtos de Juan");
            System.out.println(next.getCiclo());
            System.out.println(next.getDni());
            System.out.println(next.getNUMEXPDTE());
        } 
         */
        //Ejecucion 4
        AlumnoBean expUno = (AlumnoBean) FactoriaAlumnos.getAlumnoDao().getAlumnoPorNUMEXPDTE("1");
        
        System.out.println("Ciclo: " + expUno.getCiclo());
        System.out.println("Nombre: " + expUno.getNombre());
        System.out.println("Dni: " + expUno.getDni());
        System.out.println("NumExpdte: " + expUno.getNUMEXPDTE());
        
         //Ejecucion 5
         //FactoriaAlumnos.getAlumnoDao().deletePorNombre("Juan");
    }
}
