/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Practica1;

import java.util.Collection;
import java.util.Date;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author at4dam2
 */
public class AlumnoBean implements AlumnoInterface {

    private String NUMEXPDTE;
    private String nombre;
    private String ciclo;
    private String dni;
    private Date fecha;
    private Connection conexion = null;

    @Override
    public String getNUMEXPDTE() {
        return this.NUMEXPDTE;
    }

    @Override
    public String getNombre() {
        return nombre; // no es obligatorio poner this
    }

    @Override
    public String getCiclo() {
        return ciclo;
    }

    @Override
    public String getDni() {
        return dni;
    }

    @Override
    public Date getFecha() {
        return fecha;
    }

    @Override
    public void setNombre(String nombre, String numexpdte) {
        conexion = getConexion();

        Statement sentencia = null;

        try {
            sentencia = conexion.createStatement();
            sentencia.execute(
                    "UPDATE ALUMNOS.ALUMNO SET NOMBRE='" + nombre
                    + "'WHERE NUMEXPDTE='" + numexpdte + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de nombre sobre ALUMNO");
            return;
        }
        this.nombre = nombre;
    }

    @Override
    public void setCiclo(String ciclo, String numexpdte) {
        conexion = getConexion();

        Statement sentencia = null;
        try {
            sentencia = conexion.createStatement(); //se crea la sentencia

            sentencia.execute(
                    "UPDATE ALUMNOS.ALUMNO SET CICLO='" + ciclo
                    + "'WHERE NUMEXPDTE='" + numexpdte + "'");
            //modifico el nombre, con el nombre que nos dan de aquel cuyo expdiente coincida con el objeto actual
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de ciclo sobre ALUMNO");
            return;
        }

        this.ciclo = ciclo;
    }

    @Override
    public void setDni(String dni, String numexpdte) {
        conexion = getConexion();

        Statement sentencia = null;
        try {
            sentencia = conexion.createStatement();

            sentencia.execute(
                    "UPDATE ALUMNOS.ALUMNO SET DNI='" + dni
                    + "'WHERE NUMEXPDTE='" + numexpdte + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de dni sobre ALUMNO");
            return;
        } catch (Exception e) {
            System.out.println(e.getClass());
            return;
        }

        this.dni = dni;
    }

    @Override
    public void setFecha(Date fecha, String numexpdte) {
        conexion = getConexion();
        Statement sentencia = null;
        try {
            sentencia = conexion.createStatement();
            sentencia.execute(
                    "UPDATE ALUMNOS.ALUMNO SET FECNAC='" + fecha
                    + "' WHERE NUMEXPDTE='" + numexpdte + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en UPDATE de fecha sobre ALUMNO");
            return;
        }
        this.fecha = fecha;
    }

    @Override
    public AlumnoInterface getAlumnoPorNUMEXPDTE(String NUMEXPDTE) {

        conexion = getConexion();
        Statement sentencia = null;
        AlumnoBean alumno = null;
        try {
            sentencia = conexion.createStatement(); //se crea la sentencia

            alumno = new AlumnoBean();
            //se le da valor ejecutandola
            java.sql.ResultSet resultado;
//executeQuery devuelve ResulSet, que es un cursor
            resultado = sentencia.executeQuery(
                    "SELECT * FROM ALUMNOS.ALUMNO WHERE NUMEXPDTE='" + NUMEXPDTE + "'"
            );

            while (resultado.next()) {
                alumno.NUMEXPDTE = resultado.getString("NUMEXPDTE");
//al método getString le paso el nombre de la columna y me devuelve el valor de la columna como un String 
                alumno.ciclo = resultado.getString("CICLO");
                alumno.dni = resultado.getString("DNI");
                alumno.nombre = resultado.getString("NOMBRE");
                //en java hay dos tipos de Date:
                //java.util.date
                //java.sql.date --> para compatibilizar las fechas entre bbdd
                //getDAte devuelve java.sql.date y el alumno.fecha es de tipò java.util.date 
                //y tengo que hacer una conversión
                alumno.fecha = resultado.getDate("FECNAC");
            }
            resultado.close();
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en SELECT de Alumno por NUMEXPDTE sobre ALUMNO");
            return null;
        }
        return alumno;
    }

    @Override
    public Collection getAlumnoPorCiclo(String ciclo
    ) {
        conexion = getConexion();
        Statement sentencia = null;

        AlumnoBean alumno = null;
        java.util.Collection coleccion = null;

        try {
            sentencia = conexion.createStatement();
            coleccion = new java.util.Vector();

            //Collection no se puede instanciar, pq es un interfaz, utilizamos un Vector, un vector es un obj coleccion
            java.sql.ResultSet resultado;
            resultado = sentencia.executeQuery("SELECT * FROM ALUMNOS.ALUMNO WHERE CICLO='" + ciclo + "'");

            while (resultado.next()) {
                alumno = new AlumnoBean();
                alumno.NUMEXPDTE = resultado.getString("NUMEXPDTE");
                alumno.ciclo = resultado.getString("CICLO");
                alumno.dni = resultado.getString("DNI");
                alumno.nombre = resultado.getString("NOMBRE");
                alumno.fecha = resultado.getDate("FECNAC");
                coleccion.add(alumno);
            }
            resultado.close();
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en SELECT de Alumno por ciclo sobre ALUMNO");
            return null;
        }
        return coleccion; // Devuelve una colección de alumnos.
    }

    @Override
    public Collection getAlumnoPorNombre(String nombre
    ) {
        conexion = getConexion();

        Statement sentencia = null;
        AlumnoBean alumno = null;
        Collection coleccion = null;

        try {
            sentencia = conexion.createStatement();
            coleccion = new java.util.Vector();
            ResultSet resultado;

            resultado = sentencia.executeQuery(
                    "SELECT * FROM ALUMNOS.ALUMNO "
                    + "WHERE NOMBRE = '" + nombre + "'");

            while (resultado.next()) {

                alumno = new AlumnoBean();
                alumno.NUMEXPDTE = resultado.getString("numexpdte");
                alumno.ciclo = resultado.getString("ciclo");
                alumno.dni = resultado.getString("dni");
                alumno.nombre = resultado.getString("nombre");
                alumno.fecha = resultado.getDate("fecnac");

                coleccion.add(alumno);
            }
            resultado.close();
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error en SELECT de Alumno por nombre sobre ALUMNO " + nombre);
            return null;
        }
        return coleccion;
    }

    @Override
    public void delete() {
        conexion = getConexion();

        Statement sentencia = null;
        try {
            sentencia = conexion.createStatement();
            sentencia.execute(
                    "DELETE FROM ALUMNOS.ALUMNO WHERE NUMEXPDTE='" + this.NUMEXPDTE + "'");
            sentencia.close();
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error DELETE sobre ALUMNO");
            return;
        };

        // REInicializamos las var a su valor por defecto, ya que en java no se
        // puede destruir un objeto, por si alguien tiene una ref de este obj
        // aunque lo hayamos borrado de la base de datos , puede parecer que el obj
        //existe, para evitalo hacemos esto.
        this.ciclo = null;
        this.dni = null;
        this.NUMEXPDTE = null;
        this.fecha = null;
        this.conexion = null;
        this.nombre = null;
    }

    @Override
    public void deletePorNombre(String nombre) {
        conexion = getConexion();

        Statement sentencia = null;
        try {
            sentencia = conexion.createStatement();
            sentencia.execute(
                    "DELETE FROM ALUMNOS.ALUMNO WHERE nombre = '" + nombre + "'");
            sentencia.close();
            conexion.close();
            System.out.println("Alumno "+ nombre + " ha sido borrado.");
        } catch (SQLException e) {
            System.out.println("Error DELETE sobre ALUMNO " + nombre);
            return;
        };

        // REInicializamos las var a su valor por defecto, ya que en java no se
        // puede destruir un objeto, por si alguien tiene una ref de este obj
        // aunque lo hayamos borrado de la base de datos , puede parecer que el obj
        //existe, para evitalo hacemos esto.
        this.ciclo = null;
        this.dni = null;
        this.NUMEXPDTE = null;
        this.fecha = null;
        this.conexion = null;
        this.nombre = null;
    }

    @Override
    public AlumnoInterface getNuevoAlumno(String NUMEXPDTE, String nombre,
            String ciclo, String dni, Date fecha
    ) {
        conexion = DBConexion.getConnection();
        java.sql.Statement sentencia = null;

        try {
            sentencia = conexion.createStatement();
            /*sentencia.execute("INSERT INTO ALUMNOS.ALUMNO(NUMEXPDTE,NOMBRE,DNI,CICLO,FECNAC) VALUES('"
                    + NUMEXPDTE + "','" + nombre + "','" + dni + "','" + ciclo + "',"
                    + (fecha == null ? null : new java.sql.Date(fecha.getTime())) + ")' ");
             */
            sentencia.execute("INSERT INTO ALUMNOS.alumno(numexpdte, nombre, dni, ciclo, fecnac) VALUES ('105','ENRIQUETA','3434343','ASI',null)");
        } catch (SQLException e) {
            System.out.println("Error SQL al insertar Alumno " + e.getMessage());
            return null;
        }
        //Instanciamos alumno nuevo y le damos los valores a sus atributos
        AlumnoBean alumno = new AlumnoBean();

        alumno.NUMEXPDTE = NUMEXPDTE;
        alumno.dni = dni;
        alumno.fecha = fecha;
        alumno.nombre = nombre;
        alumno.ciclo = ciclo;
//devuelvo el objeto alumno
        return alumno;

    }
    //METODO PARA ESTABLECER LA CONEXIÓN

    private Connection getConexion() {
        String URL = "jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String PWD = "";
        String USR = "root";

        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection(URL, USR, PWD);
        } catch (SQLException e) {
            System.out.println("No se puede obtener la conexión");
            return null;
        }
        return conexion;
    }

    @Override
    public String toString() {
        return "\nNUMEXPDTE : " + NUMEXPDTE + ", nombre " + nombre + ", ciclo " + ciclo + ", dni " + dni + ", fecha " + fecha + "\n";
    }
}
