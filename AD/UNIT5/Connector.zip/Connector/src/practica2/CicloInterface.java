/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2;

/**
 *
 * @author Usuario
 */
public interface CicloInterface {
    public CicloInterface getNuevoCiclo(String codCiclo,String denCiclo,String grado); 
    
    public String getCod();
    public String getDescripcion();
    public String getGrado();
    
    public void setDescripcion(String descripcion);
    public void setGrado(String grado);
}
