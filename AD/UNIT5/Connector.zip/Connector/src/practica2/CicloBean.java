/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2;
import Practica1.DBConexion;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author Usuario
 */
public class CicloBean implements CicloInterface{
    private Connection conexion = null;
    private String codCiclo,  denCiclo,  grado;
    @Override
    public CicloInterface getNuevoCiclo(String codCiclo, String denCiclo, String grado) {
        try {
            conexion = DBConexion.getConnection();
            Statement sentencia = null;
            
            sentencia = conexion.createStatement();
            sentencia.execute("insert into ALUMNOS.CICLO VALUE('"+codCiclo+"','"+denCiclo+"','"+grado+"')");
        } catch (SQLException ex) {
            System.out.println("Fallo al inserta datos a la tabla Ciclo." + ex.getMessage());
            return null;
        }
        CicloBean ciclo = new CicloBean();
        ciclo.codCiclo = codCiclo;
        ciclo.denCiclo = denCiclo;
        ciclo.grado = grado;
       return ciclo;
    }

    @Override
    public String getCod() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getGrado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setDescripcion(String descripcion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setGrado(String grado) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
