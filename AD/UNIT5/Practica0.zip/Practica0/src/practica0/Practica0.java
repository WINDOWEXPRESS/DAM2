/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica0;
import java.sql.*;
/**
 *
 * @author alumno
 */
public class Practica0 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         try{
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","dam2","dam2");
            Statement stm=con.createStatement();
            ResultSet rs=stm.executeQuery("select * from EMP where deptno=30");
            System.out.println("Las tablas de las Base de datos de Alumnos son:");
            while(rs.next()){
                System.out.print("empno: "+rs.getString(1));
                System.out.print("ename: "+rs.getString(2));
                System.out.print("job: "+rs.getString(3));
                System.out.println("");
            }

        }catch(ClassNotFoundException | SQLException e){System.out.println("error");e.getMessage();e.getStackTrace();}
    
    }
    
}
