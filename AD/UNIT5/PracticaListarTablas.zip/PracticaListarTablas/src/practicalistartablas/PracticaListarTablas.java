
package practicalistartablas;

import java.sql.*;
public class PracticaListarTablas {

  
    public static void main(String[] args) throws SQLException,ClassNotFoundException {
      listarTablas();
    }
    
    public static void listarTablas() throws SQLException,ClassNotFoundException{
        
        Class.forName("com.mysql.jdbc.Driver");
        
        System.out.println("Getting connection");
        Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bd_alumnos","root","");
        Statement ps=c.createStatement();
        ResultSet rs=ps.executeQuery("Show tables");
        System.out.println("Las tablas son: ");
        while(rs.next()){
            String nTabla=rs.getString(1);
            System.out.println(nTabla);
        }
        rs.close();
        ps.close();
        c.close();
    }
}

