
package practica1b;
import java.sql.*;
import java.sql.SQLException;

public class Practica1B {

   
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        
        Class.forName("com.mysql.jdbc.Driver");
        
        System.out.println("Getting connection");
        Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/bdemp","root","");
            Statement ps = c.createStatement();
            ResultSet rs = ps.executeQuery("Select * from emp where deptno=30");
        while(rs.next()){
            int id = rs.getInt("empno");
            String n = rs.getString("ename");
            String j = rs.getString("job");
            int jef = rs.getInt("mgr");
            Date fec = rs.getDate("hiredate");
            double sala = rs.getDouble("sal");
            double comi = rs.getDouble("comm");
            int idep = rs.getInt("deptno");
            System.out.println("Id "+id+" Nombre "+n+" job"+j+
                    " idjefe "+jef+" Fecha Contratacion "+fec+" Salario "+sala+
                    " Comision "+comi+" IdDepartamento "+idep);   
        }
        rs.close();
        ps.close();
        c.close();
    }
    
}
