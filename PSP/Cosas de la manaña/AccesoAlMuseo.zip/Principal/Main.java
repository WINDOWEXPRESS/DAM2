package Principal;

public class Main {

	public static void main(String[] args) throws InterruptedException 
	{
		// Se utilizan valores más pequeños de aforo para las pruebas.
		Sala sala = new Sala(10,5,30); // Aforo máximo, aforo con restricción y temperatura restricción
		SensorTemperatura sensor = new SensorTemperatura(sala);
		Persona personas[] = new Persona[100];
		
		for (int i=0;i<100;i++)
		{
			personas[i] = new Persona(i,i%5,sala); // 1 de cada 5 personas es un jubilado
			personas[i].start();
		}
		sensor.start();
		
		for (int i=0;i<100;i++)
			personas[i].join();
		sensor.terminar();
	}
}
