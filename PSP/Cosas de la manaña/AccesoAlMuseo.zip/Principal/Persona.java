package Principal;

public class Persona extends Thread 
{
	private int id;
	private boolean jubilado;
	private Sala sala;
	
	public Persona (int id,int tipo,Sala sala)
	{
		this.id = id;
		if (tipo==0)
			this.jubilado = true;
		else
			this.jubilado = false;
		this.sala = sala;
	}
	
	public void run()
	{
		try 
		{
			if (jubilado)
				sala.entrarSalaJubilado();
			else
				sala.entrarSala();
			sleep(5000); // Simula el tiempo que está en la sala del museo
		} catch (InterruptedException e1) {e1.printStackTrace();}
		sala.salirSala();
	}
}
