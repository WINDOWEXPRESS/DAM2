package Principal;

public class SensorTemperatura extends Thread 
{
	private int temperaturaActual;
	private Sala sala;
	private boolean fin;
	
	public SensorTemperatura (Sala sala)
	{
		this.sala = sala;
		this.fin = false;
		this.temperaturaActual = 20;
	}
	public void terminar()
	{
		fin=true;
	}
	
	public void run()
	{
		int flip_flop=0; // Cambia de 0 a 1 y viceversa 
		while (!fin)
		{
			temperaturaActual=20+20*flip_flop; // Cambia de 20 grados a 40 y viceversa cada 3 segundos
			flip_flop=1-flip_flop;
			sala.notificarTemperatura(temperaturaActual);
			try 
			{
				sleep(3000);
			} catch (InterruptedException e) {e.printStackTrace();}
			
		}
	}

}
