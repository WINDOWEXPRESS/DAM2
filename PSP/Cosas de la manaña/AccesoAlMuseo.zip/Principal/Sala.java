package Principal;

public class Sala 
{
	private int aforoMax;
	private int aforoMaxtUmbral;
	private int tUmbral;
	private int nPersonasActual;
	private boolean activaRestriccionAforo;
	private int jubiladosEsperando;
	
	public Sala (int aforoMax,int aforoMaxtUmbral,int tUmbral)
	{
		this.aforoMax = aforoMax;
		this.aforoMaxtUmbral = aforoMaxtUmbral;
		this.tUmbral = tUmbral;
		this.nPersonasActual = 0;
		this.activaRestriccionAforo = false;
		this.jubiladosEsperando = 0;
	}
	
	public synchronized void entrarSala() throws InterruptedException
	{
		// Mientras haya jubilados esperando
		// O estando activada la Restricción de aforo por Temperatura haya más personas que aforoMaxtUmbra
		// O no estando activada la restricción de aforo por Temperatura haya más personas que aforoMax
		// la persona que desea entrar tiene que esperar
		while ((jubiladosEsperando>0) 
			||
		    (activaRestriccionAforo && nPersonasActual>=aforoMaxtUmbral)
			||
			(!activaRestriccionAforo && nPersonasActual>=aforoMax))
			wait();

		nPersonasActual++;
		System.out.println("Entra un NO jubilado. Hay "+nPersonasActual+" personas en la sala");
	}
	
	public synchronized void entrarSalaJubilado() throws InterruptedException
	{
		jubiladosEsperando++;
		System.out.println("Hay "+jubiladosEsperando+" jubilados Esperando");
		// Mientras 
		// estando activada la Restricción de aforo por Temperatura haya más personas que aforoMaxtUmbra
		// O no estando activada la restricción de aforo por Temperatura haya más personas que aforoMax
		// el jubilador que desea entrar tiene que esperar
		while ((activaRestriccionAforo && nPersonasActual>=aforoMaxtUmbral)
				||
				(!activaRestriccionAforo && nPersonasActual>=aforoMax))
				wait();

		jubiladosEsperando--;
		nPersonasActual++;
		System.out.println("Entra un jubilado. Hay "+nPersonasActual+" personas en la sala");
	}
	
	public synchronized void salirSala()
	{
		nPersonasActual--;
		System.out.println("Persona abandona la sala. Quedan "+nPersonasActual+" en la sala");
		notifyAll(); 
	}
	
	public synchronized void notificarTemperatura(int temperatura)
	{
		if (temperatura > tUmbral)
		{
			activaRestriccionAforo = true;
			System.out.println("ALERTA: Temperatura por encima del umbral");
		}
		else
			if (temperatura <tUmbral && activaRestriccionAforo==true)
			{
			 activaRestriccionAforo = false;
			 System.out.println("ALERTA: Temperatura regresa a valores adecuados");
			 notifyAll();
			}
	}
}
