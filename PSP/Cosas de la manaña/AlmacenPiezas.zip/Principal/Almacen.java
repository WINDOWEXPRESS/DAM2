package Principal;

public class Almacen 
{
	private int piezasStock;
	
	public Almacen()
	{
		this.piezasStock = 0;
	}
	
	public synchronized void agregarPiezas(int unidadesProducidas)
	{
		this.piezasStock+=unidadesProducidas;
		System.out.println("Añaden="+unidadesProducidas+" Stock="+this.piezasStock);
		notifyAll();
	}
	
	public synchronized void solicitarPiezas(int unidadesConsumidas)
	{
		try 
		{
			while (this.piezasStock<unidadesConsumidas)
				wait();
			this.piezasStock-=unidadesConsumidas;
			System.out.println("Consumen="+unidadesConsumidas+" Stock="+this.piezasStock);
		} catch (InterruptedException e) {e.printStackTrace();}
	}
}
