package Principal;

public class Consumidor extends Thread 
{
	private int unidadesConsumidas;
	private Almacen almacen;
	
	public Consumidor (int unidadesConsumidas,Almacen almacen)
	{
		this.unidadesConsumidas= unidadesConsumidas;
		this.almacen = almacen;
	}
	
	public void run()
	{
		almacen.solicitarPiezas(unidadesConsumidas);
	}
}
