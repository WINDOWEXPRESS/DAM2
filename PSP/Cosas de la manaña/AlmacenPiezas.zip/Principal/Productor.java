package Principal;

public class Productor extends Thread 
{
	private int unidadesProducidas;
	private Almacen almacen;
	
	public Productor (int unidadesProducidas,Almacen almacen)
	{
		this.unidadesProducidas = unidadesProducidas;
		this.almacen = almacen;
	}
	
	public void run()
	{
		almacen.agregarPiezas(unidadesProducidas);
	}
}
