// Un sistema de gestión de un almacén de piezas está compuesto 
// por un conjunto de productores y de consumidores que se modelan mediante hilos. 
// Los hilos productores añaden piezas, mientras que 
// los consumidores las solicitan y retiran. 
// Se pide diseñar un monitor llamado GestorPiezas que gestione las interacciones 
// de estos hilos, cuya interfaz está formada por los siguientes métodos:
// void solicitarPiezas (int cantidadPiezas) -> Este método lo invocan loz hilos consumidores cuando quieren solicitar una cantidad de piezas determinada. Si hay piezas suficientes, se le proporcionan inmediatamente (se actualiza el número de piezas almacenadas). Si no las hay, se bloquea el hilo hasta que haya suficientes. En este caso, hay que bloquear al resto de hilos consumidores hasta que se satisfaga la petición pendiente.
// void agregarPiezas (int cantidadPiezas) -> Este método lo invocan los hilos productores para añadir piezas al almacén. La cantidad de piezas que se pueden almacenar es ilimitada.

package Principal;

public class Main 
{
	public static void main(String[] args) 
	{
		Almacen almacen = new Almacen();
		
		Productor productores[] = new Productor[10];
		Consumidor consumidores[] = new Consumidor[10];
		
		for (int i=0;i<10;i++)
		{
			productores[i] = new Productor(i,almacen);
			consumidores[i] = new Consumidor(i,almacen);
			productores[i].start();
			consumidores[i].start();
		}
	}
}
