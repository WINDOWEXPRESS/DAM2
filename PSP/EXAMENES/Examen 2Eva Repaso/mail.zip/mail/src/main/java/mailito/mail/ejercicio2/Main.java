/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mailito.mail.ejercicio2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.api.mailer.config.TransportStrategy;
import org.simplejavamail.email.EmailBuilder;
import org.simplejavamail.mailer.MailerBuilder;

/**
 *
 * @author Usuario
 */
public class Main {

    private static final int NUMERO_TOTAL_PARAMETROS = 5;

    public static void main(String[] args) {
        for (String arg : args) {
            System.out.println(arg);
        }   
        // Verificar que se proporcionen los argumentos necesarios
        if (args.length != NUMERO_TOTAL_PARAMETROS) {
            System.out.println("Uso: java Main <ruta_mensajes> <ruta_dirs> <num_cifrado> <usuario_smtp> <contraseña>");
            return;
        }

        // Obtener los parámetros de entrada
        String rutaMensajes = args[0];
        String rutaDirs = args[1];
        String usuarioSmtp = args[2];
        String contrasena = args[3];
        
        Enviador enviador = new Enviador();
        enviador.setEnviarMail(new Enviador.EnviarMail() {
            @Override
            public void enviar(String s) {
                System.out.println("Ha llegado algo: "+s );
            }
        });
        
        enviador.enviarCorreo(usuarioSmtp, contrasena, rutaDirs, rutaMensajes);
        
        
        
        /*
        try {
            // Leer mensajes del archivo
            BufferedReader brMensajes = new BufferedReader(new FileReader(rutaMensajes));
            String mensaje;
            while ((mensaje = brMensajes.readLine()) != null) {
                // Leer direcciones de correo del archivo
                BufferedReader brDirs = new BufferedReader(new FileReader(rutaDirs));
                String direccion;
                while ((direccion = brDirs.readLine()) != null) {
                    // Enviar el mensaje cifrado a la dirección de correo usando SMTP
                    enviarCorreo(usuarioSmtp, contrasena, direccion, mensaje);
                }
                brDirs.close();
            }
            brMensajes.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
    }

}
