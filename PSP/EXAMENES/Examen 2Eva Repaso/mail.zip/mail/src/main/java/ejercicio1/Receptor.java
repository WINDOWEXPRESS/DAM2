/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class Receptor {

    // Interfaz para los observadores del receptor
    public interface Observer {
        // Método de actualización que será implementado por los observadores
        public void update(String mensaje);
    }

    // Tamaño máximo del buffer para recibir datos del socket
    private int MAX_LENGTH = 1024;
    private int puerto; // Puerto en el que escuchará el receptor
    private List<Observer> observers; // Lista de observadores registrados en el receptor

    // Constructor que recibe el puerto en el que escuchará el receptor
    public Receptor(int puerto) {
        this.puerto = puerto;
        observers = new ArrayList<>(); // Inicializa la lista de observadores
    }

    // Método para registrar un observador en el receptor
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    // Método para remover un observador de la lista de observadores
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    // Método privado para notificar a todos los observadores registrados
    private void notifyObservers(String data) {
        // Itera sobre la lista de observadores y llama al método update para cada uno
        for (int i = 0; i < observers.size(); i++) {
            observers.get(i).update(data);
        }
    }

    // Método principal para escuchar en el puerto especificado
    public void escuchar() {
        try {
            // Crea un nuevo socket DatagramSocket y lo inicializa con el puerto y la dirección "0.0.0.0" para escuchar en todas las interfaces de red
            try (DatagramSocket ds = new DatagramSocket(puerto, InetAddress.getByName("0.0.0.0"))) {
                byte[] buffer = new byte[MAX_LENGTH]; // Crea un buffer para almacenar los datos recibidos
                while (true) {
                    // Crea un nuevo DatagramPacket para recibir datos
                    DatagramPacket p = new DatagramPacket(buffer, MAX_LENGTH);
                    ds.receive(p); // Recibe los datos en el DatagramPacket

                    String mensaje = new String(p.getData(), 0, p.getLength()); // Convierte los datos recibidos en una cadena

                    // Verifica si se recibió la señal de fin
                    if (mensaje.equalsIgnoreCase("fin")) {
                        System.out.println("Se recibió la señal de fin. Deteniendo el receptor...");
                        break; // Si se recibe la señal de fin, detiene el bucle
                    } else {
                        notifyObservers(mensaje); // Notifica a todos los observadores con el mensaje recibido
                    }
                }
            }
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}