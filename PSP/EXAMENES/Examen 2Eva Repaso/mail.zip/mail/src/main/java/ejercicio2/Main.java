/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

import mailito.mail.ejercicio2.Enviador;

/**
 *
 * @author Usuario
 */
public class Main {
        private static final int NUMERO_TOTAL_PARAMETROS = 4;
        private static final int INDEX_MENSAJE = 0;
        private static final int INDEX_DIRECCION = 1;
        private static final int INDEX_USUARIO = 2;
        private static final int INDEX_CONTRASENIA = 3;

    public static void main(String[] args) {
 
        // Verificar que se proporcionen los argumentos necesarios
        if (args.length != NUMERO_TOTAL_PARAMETROS) {
            System.out.println("Uso: java Main <ruta_mensajes> <ruta_dirs> <usuario_smtp> <contraseña>");
            return;
        }

        // Obtener los parámetros de entrada
        String rutaMensajes = args[INDEX_MENSAJE];
        String rutaDirs = args[INDEX_DIRECCION];
        String usuarioSmtp = args[INDEX_USUARIO];
        String contrasena = args[INDEX_CONTRASENIA];
        
        // Crear instancia de LectorParaSpam
        LectorParaSpam lectorParaSpam = new LectorParaSpam(rutaMensajes, rutaDirs);

        // Crear instancia de EnviadorSpam y agregarla como observador
        EnviadorSpam enviador = new EnviadorSpam(usuarioSmtp, contrasena, lectorParaSpam);
        lectorParaSpam.addObserver(enviador);

        // Comenzar la lectura y envío de spam
        lectorParaSpam.comenzarLectura();
       
     
    }

}
