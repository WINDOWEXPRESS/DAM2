/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class LectorParaSpam {
 // Definimos la interfaz Observer
    public interface Observer {
        // Método para enviar el mensaje a la dirección especificada
        void enviar(String mensaje, String direccion);
    }

    // Variables de instancia para la ruta del mensaje y la ruta de la dirección
    private String ruta_mensaje;
    private String ruta_direccion;

    // Lista de observadores que serán notificados cuando se lea una línea de la dirección y el mensaje
    List<Observer> observers;

    // Constructor de la clase
    public LectorParaSpam(String ruta_mensaje, String ruta_direccion) {
        this.ruta_mensaje = ruta_mensaje;
        this.ruta_direccion = ruta_direccion;
        // Inicializamos la lista de observadores
        observers = new ArrayList<>();
    }

    // Método para añadir un observador a la lista
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    // Método privado para notificar a todos los observadores con el mensaje y la dirección
    private void notifyObservers(String mensaje, String direccion) {
        for (int i = 0; i < observers.size(); i++) {
            observers.get(i).enviar(mensaje, direccion);
        }
    }

    // Método para comenzar la lectura de los archivos de mensaje y dirección
    public void comenzarLectura() {
        try {
            // Abrimos los lectores de archivos
            BufferedReader lectorDireccion = new BufferedReader(new FileReader(ruta_direccion));
            BufferedReader lectorMensaje = new BufferedReader(new FileReader(ruta_mensaje));

            String direccion;
            String mensaje;

            // Leemos las líneas de ambos archivos mientras haya líneas disponibles
            while ((direccion = lectorDireccion.readLine()) != null && (mensaje = lectorMensaje.readLine()) != null) {
                // Notificamos a los observadores con el mensaje y la dirección
                notifyObservers(mensaje, direccion);
            }

            // Cerramos los lectores de archivos
            lectorDireccion.close();
            lectorMensaje.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LectorParaSpam.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LectorParaSpam.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
