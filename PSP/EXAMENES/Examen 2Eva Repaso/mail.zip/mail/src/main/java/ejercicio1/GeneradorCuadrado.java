/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author Usuario
 */
public class GeneradorCuadrado {
  
    public static String generarCuadrado(int altura, int ancho, char caracter) {
        StringBuilder cuadrado = new StringBuilder();
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < ancho; j++) {
                cuadrado.append(caracter);
            }
            cuadrado.append("\n"); // Cambiar de línea después de cada fila
        }
        return cuadrado.toString();
    }
}
