/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
/**
 *
 * @author Usuario
 */
// Clase Enviador que observa la recepción de Datagramas en Receptor 
// y envía el cuadrado generado por GeneradorCuadrado
public class Enviador implements Receptor.Observer {
    private int puertoEnvio ;
    private DatagramSocket socket;

    public Enviador(int puertoEnvio) {
        this.puertoEnvio = puertoEnvio;
        try {
            socket = new DatagramSocket();
        } catch (SocketException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void update(String mensaje) {
        // Parsear el mensaje recibido para obtener altura, ancho y carácter
        String[] partes = mensaje.split(" ");
        int altura = Integer.parseInt(partes[0]);
        int ancho = Integer.parseInt(partes[1]);
        char caracter = partes[2].charAt(0);
         // Generar el cuadrado
        String cuadrado = GeneradorCuadrado.generarCuadrado(altura, ancho, caracter);

        // Enviar el cuadrado por Broadcast UDP
        try {
            InetAddress broadcastAddress = InetAddress.getByName("0.0.0.0");
            byte[] buffer = cuadrado.getBytes();
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, broadcastAddress, puertoEnvio);
            socket.send(packet);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
