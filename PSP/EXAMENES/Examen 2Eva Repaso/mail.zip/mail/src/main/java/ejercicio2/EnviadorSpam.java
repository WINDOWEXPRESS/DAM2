/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio2;

import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.api.mailer.config.TransportStrategy;
import org.simplejavamail.email.EmailBuilder;
import org.simplejavamail.mailer.MailerBuilder;
            
/**
 *
 * @author Usuario
 */
public class EnviadorSpam implements LectorParaSpam.Observer {
    private String usuario; // Nombre de usuario del remitente del correo electrónico
    private String contrasenia; // Contraseña del remitente del correo electrónico
    private LectorParaSpam lectorParaSpam; // Objeto LectorParaSpam al que está asociado este EnviadorSpam

    // Constructor de la clase EnviadorSpam
    public EnviadorSpam(String usuario, String contrasenia, LectorParaSpam lectorParaSpam) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.lectorParaSpam = lectorParaSpam;
    }
    
    // Método de la interfaz Observer para enviar un mensaje de spam
    @Override
    public void enviar(String ruta_mensaje, String ruta_direccion) {
        // Extraer el nombre de usuario del remitente sin el dominio
        String usuarioSolo = usuario.split("@")[0];
        
        // Construir el objeto Email para el mensaje de spam
        Email email = EmailBuilder.startingBlank()
                .to(ruta_direccion.split("@")[0], ruta_direccion) // Destinatario del correo electrónico
                .from(usuarioSolo, usuario) // Remitente del correo electrónico
                .withReplyTo(usuarioSolo, usuario) // Dirección de respuesta configurada
                .withSubject("Proyecto Spamtoso") // Asunto del correo electrónico
                .withHTMLText("<h1>Hola!!</h1><p>¿Qué tal?</p>") // Cuerpo del correo electrónico en formato HTML
                .withPlainText(ruta_mensaje) // Cuerpo del correo electrónico en texto plano
                .buildEmail(); // Construir el objeto Email

        // Configurar y construir el objeto Mailer para enviar el correo electrónico
        Mailer mailer = MailerBuilder
                .withSMTPServer("smtp.educa.madrid.org", 587, usuarioSolo, contrasenia) // Configuración del servidor SMTP
                .withTransportStrategy(TransportStrategy.SMTP_TLS) // Estrategia de transporte SMTP TLS
                .clearEmailValidator() // Desactivar la validación de correo electrónico
                .buildMailer(); // Construir el objeto Mailer

        // Enviar el correo electrónico
        mailer.sendMail(email);
    }
}

