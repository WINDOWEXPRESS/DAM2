/*
 * Este programa implementa un servidor HTTP que recibe una solicitud GET con un rango de números primos
 * y devuelve una lista de números primos dentro de ese rango en formato HTML.
 */

package ejercicio3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Clase principal que actúa como servidor HTTP para buscar números primos dentro de un rango especificado.
 */
public class Main {

    // Índice del recurso en la solicitud HTTP
    private static final int RESOURCE_POSITION = 1;

    public static void main(String[] args) {

        // Verificar si se proporcionó el puerto como argumento de línea de comandos
        if (args.length != 1) {
            System.out.println("Uso: java Main <puerto escuchar>");
            return;
        }

        try {
            // Crear un servidor socket en el puerto especificado
            int puerto = Integer.parseInt(args[0]);
            ServerSocket server = new ServerSocket(puerto);

            // Bucle para aceptar conexiones entrantes de clientes
            while (true) {
                Socket connCliente = server.accept(); // Aceptar la conexión del cliente
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(
                                connCliente.getInputStream()
                        )
                );

                // Leer la primera línea de la solicitud HTTP para obtener el recurso solicitado
                String header = reader.readLine();
                System.out.println("header: " + header);

                // Obtener el recurso solicitado y sus argumentos (inicial y cantidad de números primos)
                String[] argumentosRecurso = extraeInformacion(header).split("/");
                for (String string : argumentosRecurso) {
                    System.out.println("recursos: " + string);
                }

                // Si el recurso solicitado es el icono de favicon, continuar con la siguiente solicitud
                if (argumentosRecurso[1].equals("favicon.ico")) {
                    continue;
                }

                // Convertir los argumentos del recurso a valores numéricos (inicial y cantidad)
                int inicial = Integer.parseInt(argumentosRecurso[1]);
                int cantidad = Integer.parseInt(argumentosRecurso[2]);

                // Crear una instancia de PrimosHTTP para buscar números primos en el rango especificado
                PrimosHTTP primosHTTP = new PrimosHTTP(connCliente, inicial, cantidad);

                // Agregar un observador para registrar los números primos encontrados
                Logger logger = new Logger();
                primosHTTP.addObservador(logger);

                // Generar el cuerpo HTML de la respuesta HTTP con los números primos encontrados
                String bodyHTML = generaPagina(primosHTTP);

                // Crear un escritor para enviar la respuesta HTTP al cliente
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(
                                connCliente.getOutputStream()
                        )
                );

                // Escribir la cabecera de la respuesta HTTP (código de estado y tipo de contenido)
                writer.write("HTTP/1.1 200 OK\n");
                writer.write("\n"); // Línea en blanco para separar la cabecera del cuerpo
                // Escribir el cuerpo HTML de la respuesta
                //writer.write("<html><body>"); 
                writer.write(bodyHTML); 
                // writer.write("</html></body>"); 
                writer.flush(); // Forzar la escritura de los datos al socket

                // Cerrar los lectores, escritores y la conexión con el cliente
                reader.close();
                writer.close();
                connCliente.close();
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    // Método para generar la página HTML con los números primos encontrados
    private static String generaPagina(PrimosHTTP primosHTTP) {
        StringBuilder builder = new StringBuilder();
        builder.append("<ul>\n");

        // Agregar un observador para registrar los números primos mientras se buscan
        primosHTTP.addObservador(primo -> {
            builder.append(String.format("<li> %d </li>\n", primo)); // Agregar cada número primo a la lista
            System.out.println(primo); // Imprimir el número primo en la consola
        });

        // Iniciar la búsqueda de números primos
        primosHTTP.buscarPrimos();

        builder.append("</ul>\n");

        return builder.toString(); // Devolver la página HTML generada como una cadena
    }

    // Método para extraer la información del recurso solicitado en la solicitud HTTP
    private static String extraeInformacion(String header) {
        return header.split(" ")[RESOURCE_POSITION]; // Devuelve la parte correspondiente al recurso
    }

}
