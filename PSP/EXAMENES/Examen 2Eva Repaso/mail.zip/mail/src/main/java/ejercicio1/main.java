/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio1;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class main {

    // Definir el número total de parámetros esperados en la línea de comandos
    private static int NUMERO_TOTAL_PARAMETROS = 2;

    // Método principal
    public static void main(String[] args) {
        // Verificar si se proporciona el número correcto de argumentos en la línea de comandos
        if (args.length != NUMERO_TOTAL_PARAMETROS) {
            System.out.println("Uso: java Main <puerto escucha> <puerto envio>");
            return; // Salir del programa si el número de argumentos es incorrecto
        }

        // Obtener los puertos de escucha y envío de los argumentos de la línea de comandos
        int puertoEscucha = Integer.parseInt(args[0]);
        int puertoEnvio = Integer.parseInt(args[1]);

        // Crear una instancia del receptor con el puerto de escucha especificado
        Receptor receptor = new Receptor(puertoEscucha);

        // Crear una instancia del enviador con el puerto de envío especificado
        Enviador enviador = new Enviador(puertoEnvio);

        // Registrar el enviador como observador del receptor
        receptor.registerObserver(enviador);

        // Iniciar la escucha en el receptor
        receptor.escuchar();
        }
}
