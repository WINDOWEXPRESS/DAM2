/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio3;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Usuario
 */

// Implementación de la interfaz Observador para el registro de números primos en un archivo de registro
public class Logger implements PrimosHTTP.Observador {
    // Ruta del archivo de registro
    private static final String RUTA_LOG = "/var/log/primos.txt";

    // Método para guardar el número primo en el archivo de registro
    @Override
    public void guardar(int primo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RUTA_LOG, true))) {
            // Escribir el número primo en una nueva línea en el archivo de registro
            writer.write(primo + "\n");
        } catch (IOException e) {
            // Manejar cualquier excepción de E/S al escribir en el archivo
            e.printStackTrace(); // Imprimir el seguimiento de la pila para depuración
            // Aquí podrías manejar la excepción de manera más específica o notificar al sistema de algún otro modo
        }
    }
}
