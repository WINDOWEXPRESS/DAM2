/*
 * PrimosHTTP: Clase que busca números primos y notifica a sus observadores
 */
package ejercicio3;

import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class PrimosHTTP {
    
    // Atributos de la clase
    private Socket socket;      // Socket para la conexión
    private int inicial;        // Número inicial para comenzar la búsqueda
    private int cantidad;       // Cantidad de números primos a buscar
    
    // Interfaz Observador para los objetos que deseen ser notificados
    public interface Observador {
        void guardar(int numero);   // Método para guardar el número primo encontrado
    }
    
    // Lista de observadores
    private List<Observador> observadores;
    
    // Constructor de la clase
    public PrimosHTTP(Socket socket, int inicial, int cantidad) {
        this.socket = socket;
        this.inicial = inicial;
        this.cantidad = cantidad;
        observadores = new ArrayList<>();  // Inicialización de la lista de observadores
    }
    
    // Método para agregar un observador a la lista
    public void addObservador(Observador observador) {
        observadores.add(observador);
    }
    
    // Método para notificar a todos los observadores
    public void notifyObservadores(int numero) {
        for (Observador observador : observadores) {
            observador.guardar(numero);
        }
    }
    
    // Método principal para buscar números primos
    public void buscarPrimos() {
        int numero = inicial;   // Inicializamos el número inicial
        int restantes = cantidad;   // Inicializamos la cantidad restante de números primos por encontrar
        
        // Mientras queden números primos por encontrar
        while (restantes > 0) {
            // Si el número actual es primo
            if (esPrimo(numero)) {
                notifyObservadores(numero);   // Notificamos a los observadores
                restantes--;   // Decrementamos la cantidad restante de números primos por encontrar
            }
            numero++;   // Pasamos al siguiente número
        }
    }
    
    // Método para verificar si un número es primo
    public boolean esPrimo(int numero) {
        if (numero == 2 || numero == 1) {   // Casos especiales para 1 y 2
            return true;
        }
        // Iteramos desde 2 hasta n-1 para verificar si hay algún divisor
        for (int i = 2; i < numero; i++) {
            if (numero % i == 0) {   // Si n es divisible por i, no es primo
                return false;
            }
        }
        return true;   // Si no encontramos divisores, n es primo
    }
}
