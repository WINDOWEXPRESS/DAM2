/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mailito.mail.ejercicio2;

import org.simplejavamail.api.email.Email;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.api.mailer.config.TransportStrategy;
import org.simplejavamail.email.EmailBuilder;
import org.simplejavamail.mailer.MailerBuilder;

/**
 *
 * @author Usuario
 */
public class Enviador {

    public interface EnviarMail {

        public void enviar(String s);
    }

    private EnviarMail enviarMail;

    public void setEnviarMail(EnviarMail manejador) {
        enviarMail = manejador;
    }

    public void enviarCorreo(String usuarioSmtp, String contrasena, String direccion, String mensaje) {
        // Implementar envío de correo usando SMTP
        //usuario contiene también el dominio (@educa.madrid.org)
        String usuarioSolo = usuarioSmtp.split("@")[0];
        if (enviarMail != null) {
            enviarMail.enviar(mensaje);
            //Código que envía
            Email email = EmailBuilder.startingBlank()
                    .to(direccion.split("@")[0], direccion)
                    .from(usuarioSolo, usuarioSmtp)
                    .withReplyTo(usuarioSolo, usuarioSmtp)
                    .withSubject("Proyecto Spamtoso")
                    .withHTMLText("<h1>Hola!!</h1><p>¿Qué tal?</p>")
                    .withPlainText(mensaje)
                    .buildEmail();

            Mailer mailer = MailerBuilder
                    .withSMTPServer("smtp.educa.madrid.org", 587, usuarioSolo, contrasena)
                    .withTransportStrategy(TransportStrategy.SMTP_TLS)
                    .clearEmailValidator() // turns off email validation
                    .buildMailer();

            mailer.sendMail(email);
        }

    }
}
