package Threads;

public class Banio {
    private final int CANTIDAD_MAXIMA_PERSONA = 5;
    private int numeroPersonaActual;

    public Banio() {
        this.numeroPersonaActual = 0;
    }

    public int getNumeroPersonaActual() {
        return numeroPersonaActual;
    }

    public synchronized void entraPersona(String nombreThread) {
        try {
            while (numeroPersonaActual == 5) {
                // System.out.println("El baño esta lleno tendrá que esperar");
                wait();
            }
            // Aumentar el Contador de persona
            numeroPersonaActual++;
            // Mensaje de aviso de quien ha entrado
            System.out.println("Entra " + nombreThread);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public synchronized void salirPersona(String nombreThread) {
        // Disminuir el Contador de persona
        numeroPersonaActual--;

        // Mensaje de aviso de quien ha salido
        System.out.println("\tTerminé " + nombreThread);

        // Notifica a la cola que hay hueco.
        notifyAll();
    }
}
