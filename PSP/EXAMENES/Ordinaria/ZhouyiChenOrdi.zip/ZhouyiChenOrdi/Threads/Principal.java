package Threads;

public class Principal {
    private static final int CANTIDAD_PERSONA = 20;

    public static void main(String[] args) {
        Banio banio = new Banio();
        Thread[] listPersonas = new Thread[CANTIDAD_PERSONA];

        for (int i = 0; i < CANTIDAD_PERSONA; i++) {
            listPersonas[i] = new Thread(new Persona(banio), "Thread" + i);
            listPersonas[i].start();
        }

        // for (int i = 0; i < listPersonas.length; i++) {
        // try {
        // listPersonas[i].join();
        // } catch (InterruptedException e) {
        // e.printStackTrace();
        // }
        // }
        // System.out.println("Fin de servicio del baño ,Numero actual de persona en
        // baño : "
        // + banio.getNumeroPersonaActual());
    }
}