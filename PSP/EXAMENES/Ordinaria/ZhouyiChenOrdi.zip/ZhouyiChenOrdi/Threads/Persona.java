package Threads;

public class Persona implements Runnable {
    private Banio banio;
    private final int TIEMPO_MININO = 10000;// 10s
    private final int TIEMPO_MAXIMO = 60000;// 60s = 60000ms
    // NO lo hago en construictor porque el valor me sale siempre "Main" y no
    // "Thread'i'""
    // private final String NOMBRE_HILO;

    public Persona(Banio banio) {
        this.banio = banio;

    }

    @Override
    public void run() {
        String NOMBRE_HILO = Thread.currentThread().getName().toString();

        banio.entraPersona(NOMBRE_HILO);

        // Simulacion de tiempo entre 10s a 60s
        try {
            Thread.sleep((long) ((Math.random() * (TIEMPO_MAXIMO - TIEMPO_MININO)) + TIEMPO_MININO));
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        banio.salirPersona(NOMBRE_HILO);
    }

}
