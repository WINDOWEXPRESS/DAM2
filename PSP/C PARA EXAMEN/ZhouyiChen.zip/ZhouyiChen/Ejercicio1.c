#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdbool.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>

#define RANGO_MAX 899
#define RANGO_MIN 100
#define READ 0
#define WRITE 1
#define INICIO_PIPE 2
#define CODIGO_ERROR -1
#define MULTIPLO_DIEZ 10
bool recibir_senial = false;

void manejador(int signum)
{
    printf("Recibi una senal 'SIGUSR1' de mi hijo \n");
    recibir_senial = true;
}

bool esPrimo(int num){
    if(num <= 1){
        return false;
    }
    for (size_t i = 2; i < num; i++)
    {
        if(num % i == 0){
            return false;
        }
    }
    return true;
}
int main(int argc, char const *argv[])
{
    int pipePadreEscribir[INICIO_PIPE];
    int pipeHijoEscribir[INICIO_PIPE];

    pid_t pid;

    // Crear un pipe
    if (pipe(pipePadreEscribir) == CODIGO_ERROR || pipe(pipeHijoEscribir) == CODIGO_ERROR)
    {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Bifurcar el proceso actual para crear un proceso hijo
    pid = fork();
    if (pid == CODIGO_ERROR)
    {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0)
    { // Código del proceso hijo
        int numero_recibido;
        int valor_total_primo = 0;
        bool encontrarMultiploDiez = false;

        close(pipePadreEscribir[WRITE]); // El hijo no escribirá en el pipePadreEscribir, así que cerramos el descriptor de escritura

        while (encontrarMultiploDiez != true)
        {
            // Leer el número del pipe
            read(pipePadreEscribir[READ], &numero_recibido, sizeof(numero_recibido));
            printf("Numero recibido desde padre : %d \n",numero_recibido);
            if(esPrimo(numero_recibido)){
                valor_total_primo += numero_recibido;
            }
            if(numero_recibido % MULTIPLO_DIEZ == 0){
                kill(getppid(), SIGUSR1);
                encontrarMultiploDiez = true;
            }
        }

        close(pipePadreEscribir[READ]); // Cerrar el descriptor de lectura después de leer

        // tuberia pipeHijoEscribir
        close(pipeHijoEscribir[READ]);
        write(pipeHijoEscribir[WRITE], &valor_total_primo, sizeof(valor_total_primo));
        close(pipeHijoEscribir[WRITE]);

        exit(EXIT_SUCCESS);
    }
    else
    { // Código del proceso padre
        signal(SIGUSR1, manejador);
        
        
        int numero_a_enviar;
        int resultado_recibido;

        close(pipePadreEscribir[READ]); // El padre no leerá del pipe, así que cerramos el descriptor de lectura
        while(recibir_senial != true){
            //Dormir un segundo para comprobar mas facil el resultado
            //sleep(1);
            numero_a_enviar = rand() % RANGO_MAX + RANGO_MIN ;
            // Escribir en el pipe
            if (write(pipePadreEscribir[WRITE], &numero_a_enviar, sizeof(numero_a_enviar)) == CODIGO_ERROR )
            {
                perror("write");
                exit(EXIT_FAILURE);
            }
        }

        close(pipePadreEscribir[WRITE]); // Cerrar el descriptor de escritura después de escribir

        // tuberia pipeHijoEscribir
        close(pipeHijoEscribir[WRITE]);

        read(pipeHijoEscribir[READ], &resultado_recibido, sizeof(resultado_recibido));
        close(pipeHijoEscribir[READ]);

        // Esperar a que el proceso hijo termine
        wait(NULL);
        // Imprimir el resultado recibido
        printf("El resultado obtenido desde proceso hijo imprimido por padre es  = %d\n", resultado_recibido );
 
        printf("Proceso padre terminó\n");
        
    }

    return 0;
}

