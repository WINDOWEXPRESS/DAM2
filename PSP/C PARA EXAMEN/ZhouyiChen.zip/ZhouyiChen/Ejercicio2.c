#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdbool.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>

#define MULTIPLO_CIEN 100
#define NUMERO_PARAMETROS 2
#define INDEX_PARAMETRO_HIJO 1
#define CODIGO_ERROR -1
#define HIJO_INICIAL 1

bool esPrimo(int num)
{
    if (num <= 1)
    {
        return false;
    }
    for (size_t i = 2; i < num; i++)
    {
        if (num % i == 0)
        {
            return false;
        }
    }
    return true;
}

int main(int argc, char const *argv[])
{

    if (argc != NUMERO_PARAMETROS)
    {
        fprintf(stderr, "Falta parametro por comando : %s <Cantidad hijo>\n", argv[0]);
        return 1;
    }
    // atoi metodo para pasar un string a int
    int cantidad_hijos = atoi(argv[INDEX_PARAMETRO_HIJO]);

    if (cantidad_hijos <= 0)
    {
        fprintf(stderr, "Debe ser un entero positivo.\n");
        return 1;
    }

    pid_t conjuntoHijos[cantidad_hijos];
    int recorrido_total = 0;

    // Crear múltiples hijos
    for (int i = 0; i < cantidad_hijos; ++i)
    {
        conjuntoHijos[i] = fork();
        if (conjuntoHijos[i] == CODIGO_ERROR)
        {
            perror("Error en el fork");
            exit(EXIT_FAILURE);
        }

        if (conjuntoHijos[i] == 0)
        {
            // Código del hijo
            int distancia_recorrido = 0;
            printf("El hijo %d comienza en el numero : %d\n", i + HIJO_INICIAL, MULTIPLO_CIEN * (i + HIJO_INICIAL));
            for (int j = MULTIPLO_CIEN * (i + HIJO_INICIAL); j < MULTIPLO_CIEN * MULTIPLO_CIEN; j++)
            {
                if (esPrimo(j))
                {
                    printf("\tEl primer primo es el : %d\n", j);

                    printf("\t\tdistancia_recorrido : %d\n", distancia_recorrido);
                    exit(distancia_recorrido);
                }
                distancia_recorrido += 1;
            }
        }
    }

    // Código del padre después de las bifurcaciones

    // Esperar a que todos los hijos terminen
    for (int i = 0; i < cantidad_hijos; ++i)
    {
        int status;
        waitpid(conjuntoHijos[i], &status, 0);
        if (WIFEXITED(status))
        {
            printf("status : %d\n", WEXITSTATUS(status));
            recorrido_total += WEXITSTATUS(status);
        }
    }
    printf("Proceso padre el recorrido total es : %d\n", recorrido_total);

    return 0;
}
