package com.example.examen1.contadorpasajeros;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;

import android.os.Bundle;
import android.widget.TextView;

import com.example.examen1.R;

public class PrincipalPasajero extends AppCompatActivity {
    public static final String CLAVE_TIPO = "DASDafas";
    TextView total;
    int numeroTotal = 0;
    FragmentContainerView fra1 ,fra2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal_pasajero);

        total = findViewById(R.id.e2_tView_total);
/*
        fra1 = findViewById(R.id.e2_fragmentContainerView);
        fra2 = findViewById(R.id.e2_fragmentContainerView2);
*/

        //set total por interfaz (obetener el numero por fragment)
        pasajeroWithObserver(R.id.e2_fragmentContainerView, "Niños");

        //set total por interfaz (obetener el numero por fragment)
        pasajeroWithObserver(R.id.e2_fragmentContainerView2, "Adultos");

/*        fra1.setOnClickListener(v -> {
            total.setText("Total : " + numeroTotal);
        });

        fra2.setOnClickListener(v -> {
            total.setText("Total : " + numeroTotal);
        });*/


    }

    //Usando un interfaz
    public void pasajeroWithObserver(int id_fCView, String tipo) {
        PasajerosFragment fragment = (PasajerosFragment) getSupportFragmentManager().findFragmentById(id_fCView);
        fragment.setObserver(new Observer() {
            @Override
            public void sendNumero(int numero) {
                total.setText("Total : " +  (numeroTotal + numero));
            }

            @Override
            public String sendTipo() {

               return  tipo;
            }
        });
    }
}