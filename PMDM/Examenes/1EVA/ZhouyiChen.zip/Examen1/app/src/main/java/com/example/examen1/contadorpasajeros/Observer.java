package com.example.examen1.contadorpasajeros;

public interface Observer {
    static int numeroP = 0;
    void sendNumero(int numero);
    String sendTipo();
}
