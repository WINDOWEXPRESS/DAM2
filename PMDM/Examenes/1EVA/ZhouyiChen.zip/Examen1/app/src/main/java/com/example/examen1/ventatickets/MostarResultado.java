package com.example.examen1.ventatickets;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.examen1.R;

public class MostarResultado extends AppCompatActivity {

    TextView resultado;
    Button volver,reiniciar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostar_resultado);

        resultado = findViewById(R.id.e1_tView_resultado);
        volver = findViewById(R.id.e1_bt_volver);
        reiniciar = findViewById(R.id.e1_bt_reiniciar);

        Bundle info = getIntent().getExtras();

        Viaje viaje = (Viaje) info.getSerializable(PrincipalVentaTicketsActivity.CLAVE_SERIAZABLE);
        resultado.setText(viaje.getOrigen()+" - "+viaje.getDestino()+"\n"+viaje.getFecharSalida()+"\n"+viaje.getFecharLlegada());
        volver.setOnClickListener(v -> {
            setResult(Activity.RESULT_CANCELED);
            finish();
        });
        reiniciar.setOnClickListener(v -> {
            setResult(Activity.RESULT_FIRST_USER);
            finish();
        });
    }
}