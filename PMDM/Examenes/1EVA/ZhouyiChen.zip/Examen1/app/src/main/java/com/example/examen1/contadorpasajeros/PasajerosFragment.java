package com.example.examen1.contadorpasajeros;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.examen1.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link PasajerosFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PasajerosFragment extends Fragment {
    private static final int CANTIDAD_5 = 5;
    int numeroPasajero = 0;

    TextView tipo, suma, resta;
    public final String PERSONA = ".";
    public final String PERSONA5 = "0";
    View layout;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public PasajerosFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PasajerosFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static PasajerosFragment newInstance(String param1, String param2) {
        PasajerosFragment fragment = new PasajerosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (layout == null) {
            // Inflate the layout for this fragment
            layout = inflater.inflate(R.layout.fragment_pasajeros, container, false);
        }


        tipo = layout.findViewById(R.id.e2_fragment_tView_resultado);
        suma = layout.findViewById(R.id.e2_fragment_tView_sumar);
        resta = layout.findViewById(R.id.e2_fragment_tView_restar);


        if (observer != null) {
            String tip = observer.sendTipo();
            this.setTipo(tip);
            suma.setOnClickListener(v -> {
                numeroPasajero++;
                if(numeroPasajero % CANTIDAD_5 == 0 ){
                    String cadena = tipo.getText().toString();
                    String cadenaNueva = "";
                    for (int i = tipo.getText().toString().length(); i < cadena.length()-CANTIDAD_5-1; i++) {
                        cadenaNueva += String.valueOf(cadena.charAt(i));
                    }
                    observer.sendNumero(numeroPasajero);
                    tipo.append(cadenaNueva+PERSONA5);
                }else{
                    observer.sendNumero(numeroPasajero);
                    tipo.append(PERSONA);
                }

            });
            resta.setOnClickListener(v -> {
                if (numeroPasajero > 0) {
                    numeroPasajero--;
                    observer.sendNumero(numeroPasajero);
                    String cadena = tipo.getText().toString();
                    String cadenaNueva = "";
                    for (int i = 0; i < cadena.length()-1; i++) {
                        cadenaNueva += String.valueOf(cadena.charAt(i));
                    }
                    tipo.setText(cadenaNueva);
                }
            });
        }

        return layout;

    }

    public void setTipo(String t) {
        tipo.setText(t+"\n");
    }

    private Observer observer;

    public void setObserver(Observer obs) {
        this.observer = obs;
    }
}