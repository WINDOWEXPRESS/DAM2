package com.example.examen1.ventatickets;

import java.io.Serializable;

public class Viaje implements Serializable {
    private String origen;
    private String destino;
    private String fecharSalida;
    private String fecharLlegada;

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getFecharSalida() {
        return fecharSalida;
    }

    public void setFecharSalida(String fecharSalida) {
        this.fecharSalida = fecharSalida;
    }

    public String getFecharLlegada() {
        return fecharLlegada;
    }

    public void setFecharLlegada(String fecharLlegada) {
        this.fecharLlegada = fecharLlegada;
    }
}
