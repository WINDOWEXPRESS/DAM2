package com.example.examen1.ventatickets;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class ValidacionCita {
    private final Calendar calendario = new GregorianCalendar();
    public boolean ValidacionFecha(int anio,int mes,int dia){
        if(anio<calendario.get(Calendar.YEAR)){
            return false;
        }else if ( mes < calendario.get(Calendar.MONTH)) {
            return false;
        }else return mes != calendario.get(Calendar.MONTH) || dia > calendario.get(Calendar.DATE);
    }
    public boolean ValidacionFechaVuelta(int anioIda,int mesIda,int diaIda,int anioVuelta,int mesVuelta,int diaVuelta){
        if(anioIda > anioVuelta){
            return false;
        }else if ( mesIda > mesVuelta) {
            return false;
        }else return diaVuelta > diaIda;
    }

}
