package com.example.examen1.ventatickets;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.examen1.R;

import java.util.Calendar;

public class PrincipalVentaTicketsActivity extends AppCompatActivity {
    private final Calendar CANLENDAR = Calendar.getInstance();
    //Instancia para validar fecha introducido
    private ValidacionCita validacionCita = new ValidacionCita();
    private boolean datosCorrecto = false;
    private Viaje viaje = new Viaje();
    public static String CLAVE_SERIAZABLE = "DASDadsa";

    Button reservar;
    TextView fechaIda, fechaVuelta, mensajeError;
    int anioIda,mesIda,diaIda;
    CheckBox soloIda;
    Spinner destino, origen;
    private boolean fechaIdaCorrecto = false;
    private boolean fechaVueltaCorrecto = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal_venta_tickets);

        reservar = findViewById(R.id.e1_bt_reservar);
        fechaIda = findViewById(R.id.e1_tView_fechaSalida);
        fechaVuelta = findViewById(R.id.e1_tView_fechaLlegada);
        soloIda = findViewById(R.id.e1_checkBox_soloIda);
        destino = findViewById(R.id.e1_spinner_destino);
        origen = findViewById(R.id.e1_spinner_origen);
        mensajeError = findViewById(R.id.e1_tView_error);

        ActivityResultLauncher<Intent> lanzadora = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), (result) -> {
                    if (result.getResultCode() == Activity.RESULT_FIRST_USER) {
                        destino.setSelection(0);
                        origen.setSelection(0);
                        fechaVuelta.setText(CANLENDAR.get(Calendar.YEAR) + "/" + (CANLENDAR.get(Calendar.MONTH) + 1) + "/"
                                + CANLENDAR.get(Calendar.DAY_OF_MONTH));
                        fechaIda.setText(CANLENDAR.get(Calendar.YEAR) + "/" + (CANLENDAR.get(Calendar.MONTH) + 1) + "/"
                                + CANLENDAR.get(Calendar.DAY_OF_MONTH));
                        fechaVuelta.setEnabled(true);
                        soloIda.setChecked(false);
                        mensajeError.setText("");
                    }
                }
        );


        fechaVuelta.setText(CANLENDAR.get(Calendar.YEAR) + "/" + (CANLENDAR.get(Calendar.MONTH) + 1) + "/"
                + CANLENDAR.get(Calendar.DAY_OF_MONTH));
        fechaIda.setText(CANLENDAR.get(Calendar.YEAR) + "/" + (CANLENDAR.get(Calendar.MONTH) + 1) + "/"
                + CANLENDAR.get(Calendar.DAY_OF_MONTH));

        soloIda.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                fechaVuelta.setEnabled(false);
                viaje.setFecharLlegada("Solo ida");
            } else {
                fechaVuelta.setEnabled(true);
            }
        });

        fechaIda.setOnClickListener(v -> {
            // get dia, mes and anio.
            int anio = CANLENDAR.get(Calendar.YEAR);
            int mes = CANLENDAR.get(Calendar.MONTH);
            int dia = CANLENDAR.get(Calendar.DAY_OF_MONTH);

            // Instanciar date picker dialog.
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    // pasar contexto.
                    PrincipalVentaTicketsActivity.this,
                    (view1, year, monthOfYear, dayOfMonth) -> {
                        if (validacionCita.ValidacionFecha(year, monthOfYear, dayOfMonth)) {
                            anioIda= year;
                            mesIda = monthOfYear;
                            diaIda = dayOfMonth;
                            // configurar fecha para text view.
                            fechaIda.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            viaje.setFecharSalida(fechaIda.getText().toString());
                            fechaIdaCorrecto = true;
                        }
                    },
                    //pasar fecha seleccionado en nuestro date picker.
                    anio, mes, dia);
            // mostrar date picker dialog.
            datePickerDialog.show();
        });
        fechaVuelta.setOnClickListener(v -> {
            // get dia, mes and anio.
            int anio = CANLENDAR.get(Calendar.YEAR);
            int mes = CANLENDAR.get(Calendar.MONTH);
            int dia = CANLENDAR.get(Calendar.DAY_OF_MONTH);

            // Instanciar date picker dialog.
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    // pasar contexto.
                    PrincipalVentaTicketsActivity.this,
                    (view1, year, monthOfYear, dayOfMonth) -> {
                        if (validacionCita.ValidacionFecha(year, monthOfYear, dayOfMonth)) {
                            // configurar fecha para text view.
                            fechaVuelta.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            viaje.setFecharLlegada(fechaVuelta.getText().toString());
                            fechaVueltaCorrecto = validacionCita.ValidacionFechaVuelta(anioIda,mesIda,diaIda,year
                            ,monthOfYear,dayOfMonth);

                        }

                    },
                    //pasar fecha seleccionado en nuestro date picker.
                    anio, mes, dia);
            // mostrar date picker dialog.
            datePickerDialog.show();
        });

        destino.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!parent.getItemAtPosition(position).toString().equals("Destino"))
                    viaje.setDestino(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        origen.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (!parent.getItemAtPosition(position).toString().equals("Origen"))
                    viaje.setOrigen(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        reservar.setOnClickListener(v -> {
            mensajeError.setText("");
            if (!fechaIdaCorrecto) {
                mensajeError.append("\nFecha ida erroneo!!!\n");
                datosCorrecto = false;

            } else if (!fechaVueltaCorrecto) {
                mensajeError.setText(R.string.error_fecha);
                datosCorrecto = false;
            } else if (destino.getSelectedItemPosition() == (origen.getSelectedItemPosition())) {
                mensajeError.setText(R.string.error_lugar);
                datosCorrecto = false;
            } else {
                datosCorrecto = true;
            }
            if (datosCorrecto) {
                Intent intent = new Intent(this, MostarResultado.class);
                intent.putExtra(CLAVE_SERIAZABLE, viaje);
                //Lanza atraves de ActivityResultLauncher
                lanzadora.launch(intent);
            }
        });

    }
}